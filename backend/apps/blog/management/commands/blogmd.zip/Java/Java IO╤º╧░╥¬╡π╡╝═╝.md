### Java IO的一些基础知识：

![Java IO](http://ohyn8f189.bkt.clouddn.com/17-6-24/56653106.jpg)


导图源文件保存地址：https://github.com/wanghaoxi3000/xmind
